const cartsProduct = [{}];

const carts = document.querySelectorAll("addToCart");
console.log(carts);

const addProductToCart = (product) => {
    if (cartsProduct.length == 0) {
        cartsProduct.push('product')

    } else {
        let i = 0;
        while (i < cartsProduct.length) {
            if (cartsProduct[i].id == product.id) {
                cartsProduct[i].quantity += 1;
                break
            } else i++;
        }
    }
     cartsProduct.push('product')
};

const setProductQuantity = (product) => {
    let i = 0;
        while (i < cartsProduct.length) {
            if ((cartsProduct[i].id == product.id) && (cartsProduct[i].quantity > 1)){
                cartsProduct[i].quantity -= 1;
                break
            }
                if ((cartsProduct[i].id == product.id) && (cartsProduct[i].quantity == 1))  
                {
                    cartsProduct.splice(i, 1);
                    break
                }  
         else {
                i++; }
                                        }
                                    }
